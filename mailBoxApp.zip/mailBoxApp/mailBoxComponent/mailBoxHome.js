const gridContainer = document.querySelector('.grid_container');
const collapsedClass = "nav-collapsed";
const navCollapsKey = "navCollapsed";
const nav = document.querySelector(".nav");
const navBorder = nav.querySelector(".nav-border");
let gridRow, sender, subject, mailContent, fullMailSubject, fullMailFrom, fullMailTo, fullMailCC, fullmailContent;


let inboxMailList = [
    {
        "sender":"Srinivas Sundaram",
        "subject":"Subject of Srinivas mail",
        "to": "Sruthi Kamakshi",
        "cc": "Anusha Sharma, Aditya Jain, Aakash Reddy, Priyanka Singh, Anusha Sharma, Aditya Jain, Aakash Reddy, Priyanka Singh, Anusha Sharma, Aditya Jain, Aakash Reddy, Priyanka Singh, Anusha Sharma, Aditya Jain, Aakash Reddy, Priyanka Singh, Anusha Sharma, Aditya Jain, Aakash Reddy, Priyanka Singh, Anusha Sharma, Aditya Jain, Aakash Reddy, Priyanka Singh",
        "content": "Hello Sruthi, <br> <br> This mail has been sent to you to test the mail box app content section. Please check the mail in detail. <br> <br> Regards, <br> Srinivas"
    },
    {
        "sender":"Kousalya Alichetty",
        "subject":"Subject of Kousalya mail",
        "to": "Sruthi Kamakshi",
        "cc": "Anusha Sharma, Aditya Jain, Aakash Reddy, Priyanka Singh",
        "content": "Hello Sruthi, <br> <br> This mail has been sent to you to test the mail box app content section. Please check the mail in detail.This mail has been sent to you to test the mail box app content section. Please check the mail in detail. <br> <br> Regards, <br> Kousalya"
    },
    {
        "sender":"Sreeram Krishna",
        "subject":"Subject of Sreeram mail",
        "to": "Sruthi Kamakshi",
        "cc": "Anusha Sharma, Aditya Jain, Aakash Reddy, Priyanka Singh",
        "content": "Hello Sruthi, <br> <br> This mail has been sent to you to test the mail box app content section. Please check the mail in detail. <br> <br> Regards, <br> Sreeram"
    },{
        "sender":"Narayana Murthy",
        "subject":"Subject of Narayana mail",
        "to": "Sruthi Kamakshi",
        "cc": "Anusha Sharma, Aditya Jain, Aakash Reddy, Priyanka Singh",
        "content": "Hello Sruthi, <br> <br> This mail has been sent to you to test the mail box app content section. Please check the mail in detail. <br> <br> Regards, <br> Narayana"
    },{
        "sender":"Vasudheva Vainkuntam",
        "subject":"Subject of Vasudheva mail",
        "to": "Sruthi Kamakshi",
        "cc": "Anusha Sharma, Aditya Jain, Aakash Reddy, Priyanka Singh",
        "content": "Hello Sruthi, <br> <br> This mail has been sent to you to test the mail box app content section. Please check the mail in detail. <br> <br> Regards, <br> Vasudheva"
    },
    {
        "sender":"Srinivas Sundaram",
        "subject":"Subject of Srinivas mail",
        "to": "Sruthi Kamakshi",
        "cc": "Anusha Sharma, Aditya Jain, Aakash Reddy, Priyanka Singh",
        "content": "Hello Sruthi, <br> <br> This mail has been sent to you to test the mail box app content section. Please check the mail in detail. <br> <br> Regards, <br> Srinivas"
    },
    {
        "sender":"Kousalya Alichetty",
        "subject":"Subject of Kousalya mail",
        "to": "Sruthi Kamakshi",
        "cc": "Anusha Sharma, Aditya Jain, Aakash Reddy, Priyanka Singh",
        "content": "Hello Sruthi, <br> <br> This mail has been sent to you to test the mail box app content section. Please check the mail in detail.This mail has been sent to you to test the mail box app content section. Please check the mail in detail. <br> <br> Regards, <br> Kousalya"
    },
    {
        "sender":"Sreeram Krishna",
        "subject":"Subject of Sreeram mail",
        "to": "Sruthi Kamakshi",
        "cc": "Anusha Sharma, Aditya Jain, Aakash Reddy, Priyanka Singh",
        "content": "Hello Sruthi, <br> <br> This mail has been sent to you to test the mail box app content section. Please check the mail in detail. <br> <br> Regards, <br> Sreeram"
    },{
        "sender":"Narayana Murthy",
        "subject":"Subject of Narayana mail",
        "to": "Sruthi Kamakshi",
        "cc": "Anusha Sharma, Aditya Jain, Aakash Reddy, Priyanka Singh",
        "content": "Hello Sruthi, <br> <br> This mail has been sent to you to test the mail box app content section. Please check the mail in detail. <br> <br> Regards, <br> Narayana"
    },{
        "sender":"Vasudheva Vainkuntam",
        "subject":"Subject of Vasudheva mail",
        "to": "Sruthi Kamakshi",
        "cc": "Anusha Sharma, Aditya Jain, Aakash Reddy, Priyanka Singh",
        "content": "Hello Sruthi, <br> <br> This mail has been sent to you to test the mail box app content section. Please check the mail in detail. <br> <br> Regards, <br> Vasudheva"
    }
];

let sentboxMailList = [
    {
        "to":"Anil Ravipudi,sunil kondepalli", 
        "subject":"Subject of Srinivas mail",
        "cc": "Anusha Sharma, Aditya Jain, Aakash Reddy, Priyanka Singh, Anusha Sharma, Aditya Jain, Aakash Reddy, Priyanka Singh, Anusha Sharma, Aditya Jain, Aakash Reddy, Priyanka Singh, Anusha Sharma, Aditya Jain, Aakash Reddy, Priyanka Singh, Anusha Sharma, Aditya Jain, Aakash Reddy, Priyanka Singh, Anusha Sharma, Aditya Jain, Aakash Reddy, Priyanka Singh",
        "content": "Hello there, , <br> <br> This mail has been sent to you to test the mail box app content section. Please check the mail in detail. <br> <br> Regards, <br> Srinivas"
    },
    {
        "to":"Anushka Sharma, Roja selvamani",
        "subject":"Subject of Kousalya mail",
        "cc": "Anusha Sharma, Aditya Jain, Aakash Reddy, Priyanka Singh",
        "content": "Hello there, , <br> <br> This mail has been sent to you to test the mail box app content section. Please check the mail in detail.This mail has been sent to you to test the mail box app content section. Please check the mail in detail. <br> <br> Regards, <br> Kousalya"
    },
    {
        "to":"Anu Emmanuel,Rashmi Goutham",
        "subject":"Subject of Sreeram mail",
        "cc": "Anusha Sharma, Aditya Jain, Aakash Reddy, Priyanka Singh",
        "content": "Hello there, , <br> <br> This mail has been sent to you to test the mail box app content section. Please check the mail in detail. <br> <br> Regards, <br> Sreeram"
    },{
        "to":"Konidela Varaprasad,Kishore Basiredyy",
        "subject":"Subject of Narayana mail",
        "cc": "Anusha Sharma, Aditya Jain, Aakash Reddy, Priyanka Singh",
        "content": "Hello there, , <br> <br> This mail has been sent to you to test the mail box app content section. Please check the mail in detail. <br> <br> Regards, <br> Narayana"
    },{
        "to":"Ram Pothieni,Pushpa Raj",
        "subject":"Subject of Vasudheva mail",
        "cc": "Anusha Sharma, Aditya Jain, Aakash Reddy, Priyanka Singh",
        "content": "Hello there, , <br> <br> This mail has been sent to you to test the mail box app content section. Please check the mail in detail. <br> <br> Regards, <br> Vasudheva"
    },
    {
        "to":"Anil Ravipudi,sunil kondepalli",
        "subject":"Subject of Srinivas mail",
        "cc": "Anusha Sharma, Aditya Jain, Aakash Reddy, Priyanka Singh",
        "content": "Hello there, , <br> <br> This mail has been sent to you to test the mail box app content section. Please check the mail in detail. <br> <br> Regards, <br> Srinivas"
    },
    {
        "to":"Anushka Sharma,Roja selvamani",
        "subject":"Subject of Kousalya mail",
        "cc": "Anusha Sharma, Aditya Jain, Aakash Reddy, Priyanka Singh",
        "content": "Hello there, , <br> <br> This mail has been sent to you to test the mail box app content section. Please check the mail in detail.This mail has been sent to you to test the mail box app content section. Please check the mail in detail. <br> <br> Regards, <br> Kousalya"
    },
    {
        "to":"Anu Emmanuel,Rashmi Goutham",
        "subject":"Subject of Sreeram mail",
        "cc": "Anusha Sharma, Aditya Jain, Aakash Reddy, Priyanka Singh",
        "content": "Hello there, , <br> <br> This mail has been sent to you to test the mail box app content section. Please check the mail in detail. <br> <br> Regards, <br> Sreeram"
    },{
        "to":"Konidela Varaprasad,Kishore Basiredyy",
        "subject":"Subject of Narayana mail",
        "cc": "Anusha Sharma, Aditya Jain, Aakash Reddy, Priyanka Singh",
        "content": "Hello there, , <br> <br> This mail has been sent to you to test the mail box app content section. Please check the mail in detail. <br> <br> Regards, <br> Narayana"
    },{
        "to":"Ram Pothieni,Pushpa Raj",
        "subject":"Subject of Vasudheva mail",
        "cc": "Anusha Sharma, Aditya Jain, Aakash Reddy, Priyanka Singh",
        "content": "Hello there, , <br> <br> This mail has been sent to you to test the mail box app content section. Please check the mail in detail. <br> <br> Regards, <br> Vasudheva"
    }
];

//Setting previous state of Collapse Nav bar
if(localStorage.getItem(navCollapsKey) === "true"){
    nav.classList.add(collapsedClass);
}

//Setting the Greeting Message
const userName = localStorage.getItem('loginId');
document.getElementById('greeting_msg').textContent = 'Hello '+userName;

//Adding Click event to the Navigation Border for collapse and expand action
navBorder.addEventListener("click", () => {
    nav.classList.toggle(collapsedClass);
    localStorage.setItem(navCollapsKey,nav.classList.contains(collapsedClass));
}); 

/**Show alert message */
function showAlert(message){
    let alertMsg = document.getElementById('alert-message');
    alertMsg.textContent = message;
    alertMsg.style.display = 'block';
    setTimeout(function(){
        alertMsg.style.display = 'none';
    }, 35000)
}

/**Function to Delete mail */
function deleteMail(){
    let selectedElement = document.getElementsByClassName('mail_row_selected');
    let length = selectedElement.length;
     while(selectedElement.length>0){
        selectedElement[0].remove();
    }  
    showAlert('Selected mail(s) deleted Successfully');
}

/**Function to close View Mail page */
function closeViewMailDialog(){
    let mailViewDialog = document.getElementsByClassName('fullMailView_dialog')[0];
    mailViewDialog.style.display = 'none';
}

/**Function to close Create Mail page */
function closeCreateMailDialog(){
    let createDialog = document.getElementsByClassName('createMail_dialog')[0];
    createDialog.style.display = 'none';
}

/**Function to load Create Mail page */
function loadCreateMailDialog(){
    let createDialog = document.getElementsByClassName('createMail_dialog')[0];
    createDialog.style.display = 'block';
}

/**Funtion to show Inbox Mails */
function showInbox(){
    if(currentView === 'inbox'){
        return;
    }
    document.getElementById('inbox').classList.add('selected-link-background');
    document.getElementById('sentbox').classList.remove('selected-link-background')
    currentView = 'inbox';
    createMailGrid(inboxMailList);
}

/**Function to show Sent Mails */
function showSentbox(isNewSentMailUpdate){
    if(currentView === 'sentbox' && !isNewSentMailUpdate){
        return;
    }  
    document.getElementById('sentbox').classList.add('selected-link-background');
    document.getElementById('inbox').classList.remove('selected-link-background')
    currentView = 'sentbox';
    //mailList = sentboxMailList;
    createMailGrid(sentboxMailList);
}

/**Funtion to create or update mail box
 * To Create Inbox 
 * To Create Sentbox
 * To Update Inbox with a new mail on Refresh or setTimeInterva;
 * For Updating Inbox with a new mail 'onlyAddNewMail' parameter must be send true
 */
function createMailGrid(mailList, onlyAddNewMail){
    if(!onlyAddNewMail){
        //document.getElementsByClassName('grid_container')[0].textContent = '';
        gridContainer.textContent = '';
    }   
    mailList.forEach(function(mailData){
        gridRow = document.createElement('div');
        gridRow.classList.add('mail_row');
        gridRow.addEventListener("dblclick", function () {
            let fullMailDiv = document.getElementsByClassName('fullMailView_dialog')[0];
            fullMailDiv.style.display = 'block';
            //Creating Subject Line as Header in Full Mail View
            fullMailSubject = document.querySelector('.subject_header');
            fullMailSubject.textContent = mailData.subject;
            //fullMailSubject.appendChild(document.createTextNode(mailData.subject));
            //Creating From Name section
            fullMailFrom = document.querySelector('.from_person');
            fullMailFrom.textContent = (currentView === 'inbox')? mailData.sender:userName;
            //fullMailFrom.appendChild(document.createTextNode(mailData.sender));
            //creating To Name section
            fullMailTo = document.querySelector('.to_list');
            fullMailTo.textContent = mailData.to;
            //fullMailTo.appendChild(document.createTextNode(mailData.to));
            //creating cc Name section
            fullMailCC = document.querySelector('.cc_list');
            fullMailCC.textContent = mailData.cc;
            //fullMailCC.appendChild(document.createTextNode(mailData.cc));
            fullmailContent = document.querySelector('.fullmail_content');
            fullmailContent.innerHTML = mailData.content;       
        });
    
        gridRow.addEventListener('click', function(event){
            // toggleSelection(event.currentTarget);
            event.currentTarget.classList.toggle('mail_row_selected')
        });
    
        sender = document.createElement('span');
        sender.appendChild(document.createTextNode((currentView === 'inbox')? mailData.sender:mailData.to));
        sender.classList.add('sender_name');
    
        subject = document.createElement('span');
        subject.appendChild(document.createTextNode(mailData.subject));
        subject.classList.add('subject_line');
    
        mailContent = document.createElement('span');
        let data = mailData.content;
     
        mailContent.appendChild(document.createTextNode(data.replace(/<br>/g,'')));
        mailContent.classList.add('mail_content');
    
        gridRow.appendChild(sender);
        gridRow.appendChild(subject);
        gridRow.appendChild(mailContent);
        
        if(onlyAddNewMail){
            gridContainer.prepend(gridRow);
        } else {
            gridContainer.appendChild(gridRow);
        }
        
    });
}

/**Function to logout and go back to Login page */
function logout() {
    //alert('Log Out Successful!!');
    window.open(localStorage.getItem('href')+'/loginPage/login.html', '_self')
}

/**Function to update Inbox with a newly received mail */
function updateInbox(){
    let dataObject = {
        "sender":"New Anonymous mail",
        "subject":"This is an Anonymous mail",
        "to": "Sruthi Kamakshi",
        "cc": "Anusha Sharma, Aditya Jain, Aakash Reddy, Priyanka Singh",
        "content": "Hello Sruthi, <br> <br> This mail has been sent to you to test the mail box app content section. Please check the mail in detail. <br> <br> Regards, <br> Srinivas"
    };
    let date = new Date();
    dataObject.sender += ' '+date.getSeconds();
    if(currentView === 'inbox'){
        createMailGrid([dataObject], true);
    } 
    inboxMailList.unshift(dataObject);
}

/**Mock function that acts as if to a new mail is received for every 59seconds */
setInterval(function(){
    updateInbox();
},59000)

/**To Send the newly written mail */
function sendMail(){
    closeCreateMailDialog();
    let dataObject = {
        // "sender":"Kamakshi Sruthi",
        "subject":"",
        "to": "",
        "cc": "",
        "content": ""
    };

    //Getting to/cc/subject section value and clearing to/cc/sub section for next create mail open
    dataObject.to = document.querySelector('.createMail_dialog #to_text').value;
    dataObject.cc = document.querySelector('.createMail_dialog #cc_text').value;
    dataObject.subject = document.querySelector('.createMail_dialog #sub_text').value;
    document.querySelectorAll('.createMail_dialog input[type=text]').forEach(function(element){
        element.value = '';
    });

    //Getting Content section value and clearing content section for next create mail open
    let textAreaELem = document.querySelectorAll('.createMail_dialog textarea')[0];
    dataObject.content =textAreaELem.value;
    textAreaELem.value = '';
    
    //Updating sentbox dummy mail list array
    sentboxMailList.unshift(dataObject);
    if(currentView === 'sentbox'){
        showSentbox(true);
    }
    showAlert('Mail Sent Successfully');
}



 


//CODE BACK UP - DO NOT DELETE

//close button for full mail dialog box
// document.getElementsByClassName('close_fullMailView_dialog')[0].addEventListener('click', () => {
//     let mailViewDialog = document.getElementsByClassName('fullMailView_dialog')[0];
//     mailViewDialog.style.display = 'none';
// });
//close button for pop-up window
// document.getElementsByClassName('close_createMail_dialog')[0].addEventListener('click', () => {
//     let createDialog = document.getElementsByClassName('createMail_dialog')[0];
//     createDialog.style.display = 'none';
// });

// document.getElementById('create-mail').addEventListener('click',function(){
//     let pop_up_header = document.getElementsByClassName('createMail_dialog')[0];
//     pop_up_header.style.display = 'block';
//     //Creating Subject Line as Header in create mail view
// });

// document.getElementById('delete-mail').addEventListener('click', function(){
//     let selectedElement = document.getElementsByClassName('mail_row_selected');
//     let length = selectedElement.length;
//      while(selectedElement.length>0){
//         selectedElement[0].remove();
//     }  
// });