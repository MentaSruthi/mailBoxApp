
function load_mailBox(){   
    const userName = document.querySelector('[name=loginID]').value || 'there!';
    localStorage.setItem('loginId', userName);
    let indexOfLoginPage = window.location.href.indexOf('loginPage');
    let href = window.location.href.substring(0,indexOfLoginPage);
    localStorage.setItem('href', href);
    window.open(href+'mailBoxComponent/mailBoxHome.html', '_self');
};

